class Kakak:
    def __init__(self, nama, umur):
        self.nama = nama
        self.umur= umur
 
    def Hobi(self):
        print("Main Bola")
 
class Adik:
    def __init__(self, nama, umur):
        self.nama = nama
        self.umur= umur
 
    def Hobi(self):
        print("Main Sepeda")
 
kakak= Kakak("Budi", 16)
adik = Adik("Yudi", 8)
 
for saudara in (kakak, adik):
    saudara.Hobi()