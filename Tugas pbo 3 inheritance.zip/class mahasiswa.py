print("Saya akan belajar inheritance python \n")

class Mahasiswa():
    def __init__(self, nama, nim, nomor, alamat):
        self.nama_depan = nama
        self.nim = nim
        self.noHp = nomor
        self.alamat = alamat
 
    def cek_data_mahasiswa(self):
        print('nama :', self.nama_depan, '\n\nnim :',self.nim, '\n\nnoHp:', self.noHp, '\n\nalamat :',self.alamat)
 
mahasiswa1 = Mahasiswa('Fadzlan Fairus AM', '2004297', '0852****', 'Perum. Ciujung Damai Blok C.27 No.1')
mahasiswa1.cek_data_mahasiswa()
 